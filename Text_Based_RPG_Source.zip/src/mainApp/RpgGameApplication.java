
package mainApp;
public class RpgGameApplication {



    public static void main(String[] args){


        RpgGame.getInstance().update();

    }
}
