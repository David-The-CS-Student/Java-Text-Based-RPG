
package rpgEnemyPack;
public class EnemyCreator {


    private EnemyCreator(){}


    public static GiantRat creatGiantRat(){

        return new GiantRat();
    }

    public static GiantSpider creatGiantSpider(){

        return new GiantSpider();
    }
}
